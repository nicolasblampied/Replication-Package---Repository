These files replicate Figure 4, 6, 7, B1, B2, B3, B4 and B5.

Acknowledgements: Please note that these codes has been adapted and modified departing from the do file available at Oscar Jorda's webpage: https://sites.google.com/site/oscarjorda/home/local-projections.


In order to replicate the main results of the paper, please note:


FIGURE 4, 6, and 7: 'Run Main file - Full Sample'.

Figure B1: Main file - 'Main file - Short Sample'. 
 
Figure B2: Run Main file - 'Main file - Quarterly Frequency'.

Figure B3 and B4: Main file - 'Main file - Full Sample - Additional Controls'. 

Figure B5: Main file - 'Quarterly Frequency - Proxy Markup'.